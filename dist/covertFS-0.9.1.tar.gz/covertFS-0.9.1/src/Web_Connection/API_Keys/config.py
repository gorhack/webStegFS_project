#!/usr/bin/env python3

sendSpaceKey = 'RLRS7ZQCZG'
