#!/usr/bin/env python3

proxies = {'https': 'https://165.139.149.169:3128',
           'http': 'http://165.139.149.169:3128'}
