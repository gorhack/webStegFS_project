from covertFS import console


def main():
    console.main()

if __name__ == '__main__':
    main()
